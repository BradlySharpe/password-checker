let app = {

    hibpCache: new Map(),
    worstCache: new Map(),

    chartInstance: null,

    pwdEl: document.getElementById('pwd'),
    toggleEl: document.getElementById('toggle'),
    charTableEl: document.getElementById('charTable'),
    totalCharsEl: document.getElementById('totalChars'),
    bitsEl: document.getElementById('bits'),
    verdictEl: document.getElementById('verdict'),
    whyEl: document.getElementById('why'),
    exposureListTableEl: document.getElementById('exposureListTable'),
    lengthEl: document.getElementById('length'),
    lengthVerdictEl: document.getElementById('lengthVerdict'),
    lengthWhyEl: document.getElementById('lengthWhy'),
    suggestionsEl: document.getElementById('suggestions'),
    radarCanvas: document.getElementById('passwordRadar'),
    canvasContainer: document.getElementById('containerCanvas'),

    charsets: {
        lower: {
            label: 'Lowercase Letters',
            size: 26,
            regex: /[a-z]/
        },
        upper: {
            label: 'Uppercase Letters',
            size: 26,
            regex: /[A-Z]/ 
        },
        digit: {
            label: 'Numbers',
            size: 10,
            regex: /[0-9]/   
        },
        symbol: {
            label: 'Symbols',
            size: 33,
            regex: /[!@#$%^&*()`~\-_=+\[\]{};:'"\\|,.<>/?]/
        },
        space: {
            label: 'Space',
            size: 1,
            regex: /[\s]/
        },
        // other: {
        //     label: 'Other Symbols',
        //     size: 100,
        // }
    },

    debounce(fn, delay = 300) {
        let timeout;
        return (...args) => {
            clearTimeout(timeout);
            timeout = setTimeout(() => fn(...args), delay);
        };
    },

    resizeCanvas() {
        this.render(this.pwdEl.value);
    },

    async init() {
        this.toggleEl.addEventListener('click', () => {
            const isPwd = this.pwdEl.type === 'password';
            this.pwdEl.type = isPwd ? 'text' : 'password';
            this.toggleEl.textContent = isPwd ? 'hide' : 'show';
            this.pwdEl.focus();
        });

        const debouncedRender = this.debounce(async value => await this.render(value), 300);
        this.pwdEl.addEventListener('input', e => debouncedRender(e.target.value));

        window.addEventListener('resize', this.resizeCanvas.bind(app));

        await this.render('');
    },

    async sha1(input) {
        const encoder = new TextEncoder();
        const data = encoder.encode(input);
        const hashBuffer = await crypto.subtle.digest('SHA-1', data);
        return [...new Uint8Array(hashBuffer)]
            .map(b => b.toString(16).padStart(2, '0'))
            .join('')
            .toUpperCase();
    },

    async hibpCheck(password) {
        const hash = await this.sha1(password);

        if (this.hibpCache.has(hash))
            return this.hibpCache.get(hash);

        const prefix = hash.slice(0, 5);
        const suffix = hash.slice(5);

        const res = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`);
        if (!res.ok) throw new Error(`HIBP request failed: ${res.status}`);

        const body = await res.text();

        let result = { found: false, breachCount: 0 };

        for (const line of body.split('\n')) {
            const [lineSuffix, countStr] = line.split(':');
            if (lineSuffix === suffix) {
                result = { found: true, breachCount: parseInt(countStr, 10) };
                break;
            }
        }

        this.hibpCache.set(hash, result);

        return result;
    },

    zxcvbnCheck(password) {
        if (typeof zxcvbn !== 'function')
            throw new Error('zxcvbn is not loaded or available.');

        const result = zxcvbn(password);

        return {
            crack_display: result.crack_times_display.offline_slow_hashing_1e4_per_second,
            crack_seconds: result.crack_times_seconds.offline_slow_hashing_1e4_per_second,
            guesses: result.guesses,
            guesses_log10: result.guesses_log10,
            score: result.score,
            feedback: {
                warning: result.feedback?.warning || '',
                suggestions: result.feedback?.suggestions || []
            },
            sequence: result.sequence,
            calc_time_ms: result.calc_time
        }

        /*
        Score:
            0 # too guessable: risky password. (guesses < 10^3)
            1 # very guessable: protection from throttled online attacks. (guesses < 10^6)
            2 # somewhat guessable: protection from unthrottled online attacks. (guesses < 10^8)
            3 # safely unguessable: moderate protection from offline slow-hash scenario. (guesses < 10^10)
            4 # very unguessable: strong protection from offline slow-hash scenario. (guesses >= 10^10)

        Entropy | Strength            | Explanation
        0–27    | 🔴 Very Weak        | Easily guessable in milliseconds. Equivalent to short, common passwords or single dictionary words.
        28–35   | 🟠 Weak             | May resist basic brute-force attacks, but still vulnerable. Typical of names + numbers.
        36–59   | 🟡 Moderate         | Offers some protection. Could withstand online attacks with rate limiting, but not offline brute force.
        60–79   | 🟢 Strong           | Suitable for most uses. Resists offline cracking for days or weeks.
        80–127  | 🔵 Very Strong      | Secure against offline brute-force. Typical of randomly generated 12+ character passwords with diverse character sets.
        128+    | 🟣 Extremely Strong | Overkill for most cases. Comparable to cryptographic keys. Recommended for system-generated passphrases or master keys.
        */
    },

    calculatePasswordStrength(password) {
        const charsetsUsed = new Set();
        let totalCharacters = 0;

        for (const charset of Object.keys(this.charsets)) {
            if (password.match(this.charsets[charset].regex)) {
                charsetsUsed.add(this.charsets[charset].label)
                totalCharacters += this.charsets[charset].size || 0;
            }
        }

        const entropy = Math.floor(password.length * Math.log2(totalCharacters || 1)); // avoid log2(0)

        // Map entropy to strength and explanation
        let strength, explanation, score;

        if (entropy < 28) {
            score = 0;
            strength = "Very Weak";
            explanation = "Easily guessable, avoid using common words or short passwords.";
        } else if (entropy < 36) {
            score = 1;
            strength = "Weak";
            explanation = "May survive a few guesses, but still easy to crack.";
        } else if (entropy < 60) {
            score = 2;
            strength = "Moderate";
            explanation = "Decent for online accounts with rate-limiting, but could be cracked offline.";
        } else if (entropy < 80) {
            score = 3;
            strength = "Strong";
            explanation = "Suitable for most situations.";
        } else if (entropy < 128) {
            score = 4;
            strength = "Very Strong";
            explanation = "Highly resistant to cracking attempts.";
        } else {
            score = 5;
            strength = "Extremely Strong";
            explanation = "Suitable for master passwords or encryption keys.";
        }

        return {
            score,
            entropy,
            strength,
            explanation,
            meetsComplexityPolicy: charsetsUsed.size >= 3 && password.length >= 8 ? true : false,
            charsetsUsed,
            totalCharacters
        };
    },

    async fetchList(url, type) {
        if (this.worstCache.has(url))
            return this.worstCache.get(url);

        const res = await fetch(url);
        if (!res.ok) throw new Error(`Fetch list failed: ${res.status}`);

        const content = type === 'json'
            ? await res.json()
            : await res.text();

        this.worstCache.set(url, content);

        return content;
    },

    async checkWorstPasswords(password) {
        const lists = [
            {
                url: 'https://corsproxy.io/?url=https://nordpass.com/next/worst-passwords-list/2024/b2b/au.json',
                category: 'Business Passwords',
                type: 'json'
            },
            {
                url: 'https://corsproxy.io/?url=https://nordpass.com/next/worst-passwords-list/2024/b2c/au.json',
                category: 'Consumer Passwords',
                type: 'json'
            },
            {
                url: 'https://raw.githubusercontent.com/danielmiessler/SecLists/refs/heads/master/Passwords/Common-Credentials/100k-most-used-passwords-NCSC.txt',
                category: 'Most Used Passwords',
                type: 'txt'
            }
        ];

        for (const { url, type } of lists) {
            const data = await this.fetchList(url, type);

            if (type === 'json') {
                if (data.some(entry => entry.Password === password))
                    return true;
            } else {
                if (data.split('\n').some(line => line.trim() === password))
                    return true;
            }
        }

        return false;
    },

    async check(password) {
        const [worst, hibp] = await Promise.all([
            this.checkWorstPasswords(password),
            this.hibpCheck(password)
        ]);

        const strength = this.calculatePasswordStrength(password);
        const zxcvbn = this.zxcvbnCheck(password);

        const result = { password, worst, hibp, strength, zxcvbn };

        this.renderRadarChart(result);

        return result;
    },

    renderRadarChart(data) {
        const {
            password,
            strength: { score, charsetsUsed },
            zxcvbn,
            hibp,
            worst
        } = data;

        const normalized = {
            Length: Math.min(password.length, 16) / 16 * 100,
            Randomness: (score / 5) * 100,
            'Hard to Guess': (zxcvbn.score / 4) * 100,
            'Never Seen in Data Breaches': hibp.found ? 0 : 100,
            'Not a Common Password': worst ? 0 : 100,
            'Variety of Character Types': Math.min(charsetsUsed.size, 3) / 3 * 100
        };

        const ctx = document.getElementById('passwordRadar').getContext('2d');

        if (this.chartInstance)
            this.chartInstance.destroy();

        this.chartInstance = new Chart(ctx, {
            type: 'radar',
            data: {
                labels: Object.keys(normalized),
                datasets: [{
                    label: 'Password Strength',
                    data: Object.values(normalized),
                    backgroundColor: "rgba(0, 153, 255, 0.2)",
                    borderColor: "rgba(0, 153, 255, 1)",
                    pointBackgroundColor: "#00ccff",
                    pointBorderColor: "#fff"
                }]
            },
            options: {
                responsive: false,
                maintainAspectRatio: false,
                scales: {
                    r: {
                        min: 0,
                        max: 100,
                        ticks: { display: false },
                        grid: { circular: false },
                        angleLines: {
                            color: "#444"
                        },
                        grid: {
                            color: "#333"
                        },
                        pointLabels: {
                            color: "#fff",
                            padding: 20,
                            font: {
                                size: 14,
                                weight: 800
                            }
                        },
                    }
                },
                plugins: {
                    legend: { display: false }
                }
            }
        });
    },

    async render(password) {

        const [worst, hibp] = await Promise.all([
            this.checkWorstPasswords(password),
            this.hibpCheck(password)
        ]);

        const strength = this.calculatePasswordStrength(password);
        const zxcvbn = this.zxcvbnCheck(password);

        // Build the table rows
        let rows = Object.entries(this.charsets).map(([key, {label, size}]) => {
            const used = strength.charsetsUsed.has(label);
            const icon = used ? '✅' : '❌';
            return `
                <tr>
                    <td class="icon">${icon}</span></td>
                    <td>${label}</td>
                    <td>${size} chars</td>
                </tr>`;
        }).join('');

        this.charTableEl.innerHTML = rows;
        this.totalCharsEl.textContent = `Total possible characters: ${strength.totalCharacters}`;


        const passList = [
            { found: worst, label: "on Common Password lists", none: "Common Password lists" },
            { found: hibp.found, label: "in previous Data Breaches", none: "previous Data Breaches" }
        ]

        rows = passList.map(({found, label, none}) => {
            if (password.length <= 0)
                return `<tr>
                    <td class="icon">⚠️</td>
                    <td class="warn">Unable to check ${none}</td>
                </tr>`;

            const result = !found;
            const icon = result ? '✅' : '🚨';
            const prefix = result ? 'Not found' : 'Found';
            const cls = result ? 'ok' : 'bad';
            return `
                <tr>
                <td class="icon">${icon}</td>
                <td class="${cls}">${prefix} ${label}</td>
                </tr>`;
        }).join('');

        this.exposureListTableEl.innerHTML = rows;

        this.lengthEl.textContent = `${password.length} Character${password.length == 1 ? '' : 's'}`;
        if (password.length == 0) {
            this.lengthVerdictEl.textContent = "None";
            this.lengthWhyEl.textContent = "No password entered";
            this.lengthVerdictEl.className = 'bad';
            this.lengthEl.className = 'bad';
        } else if (password.length < 5) {
            this.lengthVerdictEl.textContent = "Very Weak";
            this.lengthWhyEl.textContent = "Far too short";
            this.lengthVerdictEl.className = 'bad';
            this.lengthEl.className = 'bad';
        } else if (password.length < 8) {
            this.lengthVerdictEl.textContent = "Weak";
            this.lengthWhyEl.textContent = "Easy to guess";
            this.lengthVerdictEl.className = 'bad';
            this.lengthEl.className = 'bad';
        } else if (password.length < 11) {
            this.lengthVerdictEl.textContent = "Moderate";
            this.lengthWhyEl.textContent = "Minimum recommended";
            this.lengthVerdictEl.className = 'warn';
            this.lengthEl.className = 'warn';
        } else if (password.length < 14) {
            this.lengthVerdictEl.textContent = "Strong";
            this.lengthWhyEl.textContent = "Harder to crack";
            this.lengthVerdictEl.className = 'ok';
            this.lengthEl.className = 'ok';
        } else {
            this.lengthVerdictEl.textContent = "Excellent";
            this.lengthWhyEl.textContent = "Very hard to guess";
            this.lengthVerdictEl.className = 'ok';
            this.lengthEl.className = 'ok';
        }

        // Verdict
        this.verdictEl.textContent = strength.strength
        const className = strength.entropy < 36 ? 'bad' : strength.entropy < 60 ? 'warn' : 'ok';
        this.verdictEl.className = className;
        this.bitsEl.textContent = `~${strength.entropy} Bits`;
        this.bitsEl.className = `bits ${className}`;
        if (password == "")
            this.whyEl.textContent = "No password entered";
        else
            this.whyEl.textContent = strength.explanation;

        this.suggestionsEl.innerHTML = '';

        let suggestions = [];

        if (password !== "") {
            if (hibp.found) {
                suggestions.push(`<li class="bad">Avoid using passwords that have been exposed online, even if they seem strong. Choose a unique password that hasn't been leaked</li>`);
                
                suggestions.push(`<ul><li style="font-weight: 700">This password is no longer safe!</li><li>Please make sure to change this password on all platforms where it is used to keep your accounts secure</li></ul>`)
            }


            if (worst)
                suggestions.push(`<li class="bad">Choose a less predictable password. Avoid simple or popular phrases like "password123" or "qwerty" - they are the first to be guessed in attacks</li>`);

            if (!hibp.found && worst)
                suggestions.push(`<ul><li style="font-weight: 700">This password is not recommended.</li><li>Please make sure to change this password on all platforms where it is used to keep your accounts secure</li></ul>`)

            if (zxcvbn.feedback.warning)
                suggestions.push(`<li class="warn">${zxcvbn.feedback.warning}</li>`);

            if (!strength.meetsComplexityPolicy)
                suggestions.push(`<li class="warn">This password doesn't meet common complxity requirements, try including a mix of letters, numbers, and symbols</li>`);

            suggestions = suggestions.concat(zxcvbn.feedback.suggestions.map(s => `<li>${s}</li>`));
        }

        if (suggestions.length > 0)
            this.suggestionsEl.innerHTML = `<ul>${suggestions.join('')}</ul>`;
        else if (password.length <= 0)
            this.suggestionsEl.innerHTML = `<p class="muted">Enter a password to generate suggestions</p>`;
        else
            this.suggestionsEl.innerHTML = `<p class="ok">No suggestions - well done!</p>`;

        this.renderRadarChart({ password, worst, hibp, strength, zxcvbn });
    }
};

app.init();